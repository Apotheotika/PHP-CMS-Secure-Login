<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[Project] - User Admin</title>
<!-- Bootstrap -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link href="../css/styles.css" rel="stylesheet" media="screen">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<script src="../js/main.js"></script>
</head>
<body>
<div class="page-wrap center">
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
include $_SERVER['DOCUMENT_ROOT'] . '/header.php';
$user = new User();
if(!$user->isLoggedIn() or !$user->hasPermission('admin')){
	Session::flash('error', 'You do not have access to this page.');
	Redirect::to('index.php');
}
if (Input::exists()){
	if(Token::check(Input::get('token'))){
		$id = sanitizeInt(Input::get('user_id'));;
		$validate = new Validate();
		$validation = $validate->check($_POST, array(
			'username' => array(
				'required' => true,
				'min' => 3,
				'max' => 255,
			),
			'email' => array(
				'required' => true,
				'min' => 6,
				'max' => 255,
			),
			'permissions' => array(
				'permissions level' => intval(Input::get('permissions'))
			),
			'status' => array(
				'' => intval(Input::get('status'))
			)
		));
		if($validation->errors()){
			foreach($validation->errors() as $error){
				Session::flash('error', $error);
				Redirect::to('../admin/useradmin.php');
			}
		} else {
			echo "Updating user: " . Input::get('username') . "<br>";
			try{
				$user->update(array(
					'username' => Input::get('username'),
					'email' => Input::get('email'),
					'groups' => Input::get('permissions'),
					'account_status' => Input::get('status')
				), $id);
				Session::flash('home', 'User: ' . Input::get('username') . ' was succesfully updated.');
				Redirect::to('../admin/useradmin.php');
			} catch (Exception $e){
				die($e->getMessage());
			}
		}
	} else {
		$id = sanitizeInt(Input::get('edit'));
	}
	$data = DB::getInstance()->get('users', array('id', '=', $id));
	$data = $data->first();
	$groups = DB::getInstance()->get('groups', array('id', '>', '0'));
	$groups = $groups->results();
}
?>
<h3>Edit User</h3>
<table>
	<form action="" method="POST">
	<tr>
		<td><label for="username">Username: </label></td>
		<td><input type="text" name="username" id="username" value="<?php echo escape($data->username); ?>" autocomplete="off"/></td>
	</tr>
	<tr>
		<td><label for="email">Email: </label></td>
		<td><input type="email" name="email" id="email" value="<?php echo escape($data->email); ?>" autocomplete="off"/></td>
	</tr>
	<?php if (isset($groups)): ?>
		<tr>
			<td><label for="permissions">Permissions level: </label></td>
			<td><select name="permissions" id="permissions">
			<?php foreach($groups as $d): ?>
				<option value="<?php echo escape($d->id); ?>"><?php echo escape($d->name); ?></option>
			<?php endforeach; ?>
			</select></td>
		</tr>
	<?php endif; ?>
	<tr>
		<td><label for="status">Account status: </label></td>
		<td><select name="status" id="status">
			<option value="0">Inactive <?php if($data->account_status == 0): ?> - Current setting<?php endif; ?></option>
			<option value="1">Active <?php if($data->account_status == 1): ?> - Current setting<?php endif; ?></option>
		</select></td>
	</tr>
	<tr><td colspan="2"><input type="hidden" name="token" value="<?php echo Token::generate(); ?>"/>
		<input type="hidden" name="user_id" value="<?php echo $data->id; ?>"/>
		<input type="submit" value="Update user" class='btn btn-primary'></td>
	</tr>		
	</form>
</table>
</div>
</body>
</html>