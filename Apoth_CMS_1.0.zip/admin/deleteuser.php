<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[Project] - User Admin</title>
<!-- Bootstrap -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link href="../css/styles.css" rel="stylesheet" media="screen">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<script src="../js/main.js"></script>
</head>
<body>
<div class="page-wrap center">
<h3>Delete user</h3>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
include $_SERVER['DOCUMENT_ROOT'] . '/header.php';
$user = new User();
if(!$user->isLoggedIn() or !$user->hasPermission('admin')){
	//Session::flash('error', 'You do not have access to this page.');
	Redirect::to('index.php');
}
if (Input::exists()){

	$id = null !== Input::get('delete') ? intval(Input::get('delete')) : false;
	$delete_id = null !== intval(Input::get('delete_id')) > 0 ? intval(Input::get('delete_id')) : false;
	$cancel = null != Input::get('Cancel') ? true : false;

	if($cancel){
		Session::flash('info', 'Delete user cancelled');
		Redirect::to('../admin/useradmin.php');
	} else if (intval($delete_id) > 0){
		$user->purgeUser(intval($delete_id));
	}
	
	if($user->find($id)):
?>
	<h4>Are you sure you want to delete user: <?php echo escape($user->data()->username); ?>?</h4>
	<table>
			<tr>
				<td>
					<form action="" method="POST">
					<input type="hidden" name="delete_id" id='delete_id' value="<?php echo intval($user->data()->id); ?>"/>
					<input type="submit" value="Confirm delete" class='btn btn-danger'>
					</form>
				</td>
				<td>
					<form action="" method="POST">
					<input type="submit" name='Cancel' id='Cancel' value="Cancel" class='btn btn-info'>
					</form>
				</td>
			</tr>
	</table>
<?php  endif; 
}
?>
</div>
</body>
</html>