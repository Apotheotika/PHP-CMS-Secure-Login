<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[Project] - Change Your Password</title>
<!-- Bootstrap -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link href="../css/styles.css" rel="stylesheet" media="screen">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<script src="../js/main.js"></script>
</head>
<body>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
include $_SERVER['DOCUMENT_ROOT'] . '/header.php';
$user = new User();
// Verify logged in
$user = new User();
if(!$user->isLoggedIn()){
	Redirect::to('index.php');
}
// Test for passed input
if(Input::exists()){
	// Check if token from form is valid
	if(Token::check(Input::get('token'))){
		// Validate input
		$validate = new Validate();
		$validation = $validate->check($_POST, array(
			'current' => array(
				'required' => true,
				'min' => 12
			),
			'password' => array(
				'required' => true,
				'min' => 12,
				'max' => 255
			),
			'confirm' => array(
				'required' => true,
				'min' => 12,
				'max' => 255,
				'matches' => 'password'
			)
		));
		
		if($validation->passed()){
			// Test if password given is correct
			if(Hash::make(Input::get('current'), $user->data()->salt) !== $user->data()->password){
				echo "Incorrect password given.<br>";
			} else {
				$salt = Hash::salt(64);
				$token = hash('sha512', Hash::salt(64));
				$user->update(array(
					'password' => Hash::make(Input::get('password'), $salt),
					'salt' => $salt,
					'token' => $token
				));
				
				Session::flash('home', 'Your password has been changed');
				Redirect::to('index.php');
			}
		} else {
			foreach($validation->errors() as $error){
				echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					<strong>Error: </strong> ' . $error . '
				</div>';
			}
		}
		
	}
}
?>
<div class="page-wrap center">
<h3>Change Password</h3>
<table>
<form action="" method="POST">
	<tr>
		<td><label for="current">Current password: </label></td>
		<td><input type="password" name="current" id="current" value=""/></td>
	</tr>
	<tr>
		<td><label for="password">New password: </label></td>
		<td><input type="password" name="password" id="password" value=""/></td>
	</tr>
	<tr>
		<td><label for="confirm">Confirm password: </label></td>
		<td><input type="password" name="confirm" id="confirm" value=""/></td>
	</tr>
	<tr>
		<td colspan="2"><input type="hidden" name="token" value="<?php echo Token::generate(); ?>"/>
		<input type="submit" value="Change Password" class='btn btn-primary'/></td>
	</tr>
</form>
</table>
</div>
</body>
</html>