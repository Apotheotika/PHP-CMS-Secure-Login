<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[Project] - Home</title>
<!-- Bootstrap -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link href="../css/styles.css" rel="stylesheet" media="screen">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<script src="../js/main.js"></script>
</head>
<body>
<div class="page-wrap center">
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
include $_SERVER['DOCUMENT_ROOT'] . '/header.php';

// Check if input exists. If so, send to Validate. 
if(Input::exists()){
	// Check if Token is valid
	if(Token::check(Input::get('token'))){
		$validate = new Validate();
		// Send fields for validation with rules in nested arrays
		$validation = $validate->check($_POST, array(
			// TO DO - Validation for making usernames NOT be able to be only numeric. 
			'username' => array(
				'required' => true,
				'min' => 3,
				'max' => 20,
				'unique' => 'users'
			),
			'email' => array(
				'required' => true,
				'min' => 6,
				'max' => 255,
				'unique' => 'users'
			),
			'password' => array(
				'required' => true,
				'min' => 12,
				'max' => 255
			),
			'confirm' => array(
				'required' => true,
				'min' => 12,
				'max' => 255,
				'matches' => 'password'
			)
		));
		
		
		if($validation->passed()){
			$user = new User();
			
			$salt = Hash::salt(64);
			$token = hash('sha512', Hash::salt(64));
			
			try {
				
				$user->create(array(
					'username' => Input::get('username'),
					'password' => hash::make(Input::get('password'), $salt),
					'salt' => $salt,
					'token' => $token,
					'email' => Input::get('email'),
					'joined' => date("Y-m-d H:i:s"),
					'groups' => 1
				));
				
				$subject = "Project Account Activation";
				$message = "<p>Hello, " . escape(Input::get('username')) . "!</p>
					<p>To activate your account, <a href='" . $_SERVER['SERVER_NAME'] . "/activate.php?token=" . $token . "'>click here</a>, or copy and paste the following link into your browser:</p>
					<p>" . $_SERVER['SERVER_NAME'] . "/activate.php?token=" . $token . "</p>
					<p>Cheers,</p> 
					<p>The " . $_SERVER['SERVER_NAME'] . " Crew</p>";
				if(send_mail(escape(Input::get('email')), $message, $subject)){
					Session::flash('home', 'You have been registered successfully. An email has been sent to ' . Input::get('email') . ' for activation.');
					Redirect::to('index.php');
				};
				
				
			} catch (Exception $e) {
				die($e->getMessage());
			}
		} else {
			foreach($validation->errors() as $error){
				echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					<strong>Error: </strong> ' . $error . '
				</div>';
			}
		}
	}
}

?>

<table>
<form action="" method="POST">
	<tr>
		<td><label for="username">Username: </label></td>
		<td><input type="text" name="username" id="username" value="<?php echo escape(Input::get('username')); ?>" autocomplete="off"/></td>
	</tr>
	<tr>
		<td><label for="email">Email: </label></td>
		<td><input type="email" name="email" id="email" value="<?php echo escape(Input::get('email')); ?>" autocomplete="off"/></td>
	</tr>
	<tr>
		<td><label for="password">Password: </label></td>
		<td><input type="password" name="password" id="password" value=""/></td>
	</tr>
	<tr>
		<td><label for="confirm">Confirm Password: </label></td>
		<td><input type="password" name="confirm" id="confirm" value=""/></td>
	</tr>
	<tr><td colspan="2"><input type="hidden" name="token" value="<?php echo Token::generate(); ?>"/>
	<input type="submit" value="Register" class='btn btn-primary'/></td></tr>
</form>
</table>
</div>
</body>
</html>