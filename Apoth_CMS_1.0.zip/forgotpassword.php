<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[Project] - Forgot your password</title>
<!-- Bootstrap -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link href="../css/styles.css" rel="stylesheet" media="screen">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<script src="../js/main.js"></script>
</head>
<body>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
include $_SERVER['DOCUMENT_ROOT'] . '/header.php';

if(Input::exists('GET')){
	if (null !== Input::get('resetKey') and Input::get('resetKey') != '' and Input::get('resetKey') === escape(Input::get('resetKey'))){
		$_GET['token'] = Input::get('resetKey');
		$validate = new Validate();
		$validation = $validate->check($_GET, array(
			'token' => array(
				'required' => true,
				'length' => 128,
				'exists' => 'users'
			)
		));
		if($validation->passed()){
			Redirect::to('resetpassword.php?token=' . escape(Input::get('resetKey')));
		} else {
			Session::flash('error', 'Sorry, we are unable to locate an account with information provided.');
			Redirect::to('index.php');
		}
	} else {
		Session::flash('error', 'Invalid reset key. Please try again.');
		Redirect::to('index.php');
	}
	
} else if (Input::exists('POST')){
	if(Token::check(Input::get('token'))){
		$user = new User();
		
		$username = Input::get('username');
		if (isset($username) and $username != ''){
			if ($username != escape($username)){
				Session::flash('error', 'Invalid information given. Please try again.');
				Redirect::to('index.php');
			} else {
				$data = false;
				//test if was username or email provided. Test for the @ symbol. 
				if(strpos($username, '@') !== false){
					echo "Email provided: " . $username . "<br>";
					$data = DB::getInstance()->get('users', array('email', '=', Input::get('username')));
				} else {
					echo "Username provided: " . $username . "<br>";
					$data = DB::getInstance()->get('users', array('username', '=', Input::get('username')));
				}
				if ($data->count()){
					echo "Data found.<br>";
					$data = $data->first();
					$subject = "Password reset for " . $_SERVER['SERVER_NAME'];
					$message = "<p>Hello, {$data->username}!</p>
					<p>You are receiving this email because someone requested a password reset for your account. If this was not you, do nothing with this email and your password 
					will stay as-is. If it was you who requested the password reset, you can <a href='" . $_SERVER['SERVER_NAME'] . "/forgotpassword.php?resetKey={$data->token}'>Click here</a>.
					Alternatively (or if the link doesn't work), you can copy and paste the following into your browser:</p><p>" . 
					$_SERVER['SERVER_NAME'] . "/forgotpassword.php?resetKey={$data->token}</p>
					<p>Cheers,</p>
					<p>{$_SERVER['SERVER_NAME']} Staff</p>";
					if(send_mail(escape($data->email), $message, $subject)){
						Session::flash('home', 'We have sent an email with further instructions for restting your password.');
						Redirect::to('index.php');
					}
				} else {
					Session::flash('error', 'Sorry, we are unable to locate an account with information provided.');
					Redirect::to('index.php');
				}
			}
			
		}
	}
}
?>
<div class="page-wrap center">
<h3>Forgot password</h3>

<form action="" method="POST">
	<div class="field">
		<label for="username">Enter username or email address on account: </label>
		<input type="text" name="username" id="username" value="<?php echo escape(Input::get('username')); ?>" autocomplete="off"/>
	</div>
	<input type="hidden" name="token" value="<?php echo Token::generate(); ?>"/>
	<input type="submit" value="Send Email"/>
</form>
</div>
</body>
</html>