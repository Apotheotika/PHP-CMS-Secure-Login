<?php

// Function to output to js console
function console($output){
	echo "<script>console.log('" . $output . "');</script>";
}

// Output escape function
function escape($string){
	return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

//function to send mail
function send_mail($email, $message, $subject)
{
	require_once $_SERVER['DOCUMENT_ROOT'] . '/inc/mailer/class.phpmailer.php';
	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPDebug = 2; //0 - Prod || 2 Debug
	$mail->Debugoutput = function($str, $level) {echo "debug level $level; message: $str";}; //Debug output, disable for prod
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "ssl";
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 465;
	$mail->AddAddress($email);
	$mail->Username="poopenomics@gmail.com";
	$mail->Password="What the fuck?";
	$mail->SetFrom('poopenomics@gmail.com', 'Poopenomics');
	$mail->AddReplyTo("poopenomics@gmail.com","Poopenomics");
	$mail->Subject = $subject;
	$mail->MsgHTML($message);
	if ($mail->Send()){
		return true;
	};
	return false;
}

//////////////////////////////////////////////// SANITIZE INPUT FUNCTIONS
function sanitizeString($string){
	if ($string != filter_var($string, FILTER_SANITIZE_STRING)){
		Session::flash('error', 'Invalid field format');
		Redirect::to('../index.php');
	} else {
		return filter_var($string, FILTER_SANITIZE_STRING);
	}
}
function sanitizeEmail($email){
	if ($email != filter_var($email, FILTER_VALIDATE_EMAIL)){
		Session::flash('error', 'Invalid email format');
		Redirect::to('../index.php');
	} else {
		return filter_var($email, FILTER_VALIDATE_EMAIL);
	}
}
function sanitizeFloat($float){
	if ($float != filter_var($float, FILTER_VALIDATE_FLOAT)){
		Session::flash('error', 'Invalid number format');
		Redirect::to('../index.php');
	} else {
		return filter_var($float, FILTER_VALIDATE_FLOAT);
	}
}
function sanitizeInt($int){
	if ($int != filter_var($int, FILTER_VALIDATE_INT)){
		Session::flash('error', 'Invalid number format');
		Redirect::to('../index.php');
	} else {
		return filter_var($int, FILTER_VALIDATE_INT);
	}
}