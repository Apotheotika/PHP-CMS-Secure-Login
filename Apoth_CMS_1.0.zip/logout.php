<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
$user = new User();
$user->logout();
Redirect::to('index.php');