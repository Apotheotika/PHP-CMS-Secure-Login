<?php

class DB {
	private static $_instance = null;
	private $_pdo, $_query, $_error = false, $_results, $_count = 0;
	
	private function __construct(){
		try {
			$this->_pdo = new PDO("mysql:host=" . Config::get('mysql/host') . ";dbname=" . Config::get('mysql/db'), Config::get('mysql/username'), Config::get('mysql/password'));
			$this->_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
		} catch (PDOException $e){
			die("Error connecting to db: " . $e->getMessage());
		}
	}
	
	
	// Singleton method
	public static function getInstance(){
		if(!isset(self::$_instance)){
			self::$_instance = new DB();
		}
		return self::$_instance;
	}
	
	// Query method, will be built on with action method. Returns query object.
	public function query($sql, $params = array()){
		$this->_error = false;
		
		// Test if query can be prepared. 
		if($this->_query = $this->_pdo->prepare($sql)){
			$x = 1;
			// Check number of paramaters passed in query. Bind values for each param needed.
			if(count($params)){
				foreach($params as $param){
					$this->_query->bindValue($x, $param);
					$x++;
				}
			}
			// Execute query if prepared, save results and count in private vars
			if($this->_query->execute()){
				$this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
				$this->_count = $this->_query->rowCount();
			} else { // Flag error if execute failed.				
				$this->_error = true;
			}
		}
		return $this;
	}
	
	// Action method. Take input to form query. 
	public function action($action, $table, $where = array()){
		if(count($where) === 3){
			$operators = array('=', '<', '>', '<=', '>=');
			$field = $where[0];
			$operator = $where[1];
			$value = $where[2];
			
			if(in_array($operator, $operators)){
				$sql = "{$action} FROM {$table} WHERE {$field} {$operator} ?";
				if(!$this->query($sql, array($value))->error()){
					return $this;
				}
			}
		}
		return false;
	}
	
	// Insert method. Will set insert sql to parse out by all values to insert provided. Returns boolean.
	// TO DO - Look into way to not trigger warning from query -> insert (GENERAL ERROR HY000)
	public function insert($table, $fields = array()){
		$keys = array_keys($fields);
		$values = null;
		$x = 1;
		
		foreach($fields as $field){
			$values .= '?';
			if($x < count($fields)){
				$values .= ', ';
			}
			$x++;
		}
		
		$sql = "INSERT INTO {$table} (`" . implode('`, `', $keys) . "`) VALUES ({$values})";
		
		if(!$this->query($sql, $fields)->error()){
			return true;
		}
		return false;
	}
	
	// Update method. Will prepare insert statement. Returns boolean 
	// TO DO - Look into way to not trigger warning from query -> insert (GENERAL ERROR HY000)
	public function update($table, $id, $fields = array()){
		$set = '';
		$x = 1;
		
		foreach($fields as $name => $value){
			$set .= "{$name} = ?";
			if($x < count($fields)){
				$set .= ', ';
			}
			$x++;
		}				
		$sql = "UPDATE {$table} SET {$set} WHERE id = {$id}";
		
		if(!$this->query($sql, $fields)->error()){
			return true;
		}
		return false;
	}
	
	// Get method, uses action
	public function get($table, $where){
		return $this->action('SELECT *', $table, $where);
	}
	
	// Delete method, uses action
	public function delete($table, $where){
		return $this->action('DELETE ', $table, $where);
	}
	
	// Results method. Returns results object from query.
	public function results(){
		return $this->_results;
	}
	
	
	// Method to test if error flagged. Returns boolean
	public function error(){
		return $this->_error;
	}
	
	// Count method. Return integer set from rowCount on query.
	public function count(){
		return $this->_count;
	}
	
	// First method. Returns only first result (object) from query object.
	public function first(){
		return $this->results()[0];
	}
		
	
}