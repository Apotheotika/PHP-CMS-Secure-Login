<?php

class Session {
	
	// Method to check if Session variable exists. Returns boolean.
	public static function exists($name){
		return (isset($_SESSION[$name])) ? true : false;
	}	
	
	// Method to set session variable. Returns value.
	public static function put($name, $value){
		return $_SESSION[$name] = $value;
	}
	
	// Method to delete token. Returns boolean.
	public static function delete($name){
		if(self::exists($name)){
			unset($_SESSION[$name]);
		}
	}
	
	// Method to get session variable
	public static function get($name){
		return $_SESSION[$name];
	}
	
	// Flashing method (one time message output)
	public static function flash($name, $string = ''){
		if(self::exists($name)){
			$session = self::get($name);
			self::delete($name);
			return $session;
		} else {
			if($name == 'home'){
				$string = '<div class="alert alert-success alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					<strong>Success! </strong> ' . $string . '
				</div>';
			} else if ($name == 'error'){
				$string = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					<strong>Error: </strong> ' . $string . '
				</div>';
			} else {
				$string = '<div class="alert alert-info alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					<strong>Info: </strong> ' . $string . '
				</div>';
			}
			
			
			self::put($name, $string);
		}
	}
	
}