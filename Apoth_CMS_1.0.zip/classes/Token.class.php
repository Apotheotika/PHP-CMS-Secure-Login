<?php

class Token {
	
	// Method to set Token value as random sha512 string
	public static function generate(){
		return Session::put(Config::get('session/token_name'), hash('sha512', uniqid()));
	}
	
	// Method to check if Token is valid. Returns boolean.
	public static function check($token){
		$tokenName = Config::get('session/token_name');
		
		if(Session::exists($tokenName) and $token === Session::get($tokenName)){
			Session::delete($tokenName);
			return true;
		}
		return false;
	}
	
}