<?php

class Input{
	
	// Method to detect if input passed, defaults to POST
	public static function exists($type = 'POST'){
		switch($type){
			case 'POST':
				return (!empty($_POST)) ? true : false;
			break;
			
			case 'GET':
				return (!empty($_GET)) ? true : false;
			break;
			
			default:
				return false;
			break;
		}
	}
	
	// Method to get post or get variables. Return value requested. Returns empty string if failed.
	public static function get($item){
		if(isset($_POST[$item])){
			return $_POST[$item];
		} else if (isset($_GET[$item])) {
			return $_GET[$item];
		}
		return '';
	}
	
}