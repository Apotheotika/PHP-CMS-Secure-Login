<?php

class Redirect {
	
	// Method to set redirects. Will differ from numerical (for 404's mostly) as well, then direct as requested.
	public static function to($location = null){
		if($location){
			if(is_numeric($location)){
				switch($location){
					case 404:
						header('HTTP/1.0 404 Not Found');
						include $_SERVER['DOCUMENT_ROOT'] . '/inc/errors/404.php';
						exit();
					break;
					
					
					
					default:
						return false;
					break;
				}
			} else {
				switch($location){
					case 'inactive':
						header('Location: inactive.php');
						exit();
					break;
					
					default:
						header('Location: ' . $location);
						exit();
					break;
				}
			}
		}
		return false;
	}
	
}