<?php

class Hash {

	// Method to generate a hash. Returns string.
	public static function make($string, $salt = ''){
		return hash('sha512', $string . $salt);
	}
	
	// Method to generate a random salt
	public static function salt($length){
		return random_bytes(64);
	}
	
	// Method to generate a random default hash
	public static function unique(){
		return self::make(uniqid());
	}
}