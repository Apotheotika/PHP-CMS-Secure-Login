<?php

class Validate {
	private $_passed = false, $_errors = array(), $_db = null;
	
	public function __construct(){
		$this->_db = DB::getInstance();
	}
	
	// Method to check input based on provied params
	public function check($source, $items = array()){
		// for each item passed to be checked, break out the nested array as key => value
		foreach($items as $item => $rules){
			// For rules array, break out to rule => rule value. Runs through switch to validate if passed value meets desired requirement.
			foreach($rules as $rule => $rule_value){
				$value = trim($source[$item]);
				$item = escape($item);
				
				if($rule === 'required' && empty($value)){ // Check if rule is required and value is empty
					$this->addError("{$item} is required.");
				} else if (!empty($value)){
					switch($rule){
						case 'min':
							if(strlen($value) < $rule_value){
								$this->addError("{$item} must be a minimum of {$rule_value} characters.");
							}
						break;
						
						case 'max':
							if(strlen($value) > $rule_value){
								$this->addError("{$item} must be less than {$rule_value} characters.");
							}
						break;
						
						case 'matches':
							if($value != $source[$rule_value]){
								$this->addError("{$rule_value} and {$item} must match.");
							}
						break;
						
						case 'unique':
							$check = $this->_db->get($rule_value, array($item, '=', $value));
							if($check->count()){
								$this->addError("{$item} already exists.");
							}
						break;
						
						case 'length':
							if(strlen($value) != $rule_value){
								$this->addError("Incorrect {$item} length");
							}
						break;
						
						case 'exists':
							$check = $this->_db->get($rule_value, array($item, '=', $value));
							if(!$check->count()){
								$this->addError("Unable to locate {$item}");
							}
						break;
						
						case 'permissions level':
							if(intval($rule_value) > 4){
								$this->addError("{$rule_value} is not a valid {$value}");
							}
						break;
						
						case 'activation status':
							if(intval($rule_value) > 1){
								$this->addError("{$rule_value} is not a valid {$value}");
							}
						break;
					}
				}
				
			}
		}
		
		// Check if any errors were set, if not, set passed as true
		if(empty($this->_errors)){
			$this->_passed = true;
		}
		return $this;
	}
	
	
	// Method to add error(s) to array
	private function addError($error){
		$this->_errors[] = $error;
	}
	
	// Method to return the array/list of errors
	public function errors(){
		return $this->_errors;
	}
	
	// Method to test if validation passed
	public function passed(){
		return $this->_passed;
	}
	
}