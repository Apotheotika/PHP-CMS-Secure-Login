$(document).ready(function(){
	console.log("Ready!");
	
	$(".page-wrap").css('margin-top', $(".topnav").height() + 10 + "px");
	$(window).resize(function(){
		$(".page-wrap").css('margin-top', $(".topnav").height() + 10 + "px");
	});
	
	
});

function menuButton(){
	var x = document.getElementById("topnav");
	if(x.className === "topnav"){
		x.className += " responsive";
	} else {
		x.className = "topnav";
	}
}


