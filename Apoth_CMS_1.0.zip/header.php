<div class="header">
<?php 
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/init.php';
$user = new User();
if(!$user->isLoggedIn()){
?>
	<div class='login'><span><a href='login.php'>Login</a> or <a href='register.php'>Register</a></span></div>
<?php
} else {
?>
	<div class="topnav" id="topnav">
		<a href="../index.php">[LOGO]</a>
		<a href="../profile.php?user=<?php echo escape($user->data()->username); ?>"><?php echo escape($user->data()->username); ?> (Your account)</i></a>
		<a href="#">Dummy Link 1</a>
		<a href="../update.php">Update email</a>
		<a href="../changepassword.php">Change Password</a>
		<a href="../logout.php">Logout</a>
		<a href="javasscript:void(0);" class="icon" onclick="menuButton()">
			<i class="fa fa-bars"></i>
		</a>
<?php
	if($user->hasPermission('admin')){
		echo "<a href='../admin/useradmin.php'>User admin</a>";
	} else if ($user->hasPermission('moderator')){
		echo "Mod squad.<br>";
	}
?>
	</div>
<?php
}
?>
</div>

