<?php
// examples, no advanced output
?>
<style>
table{
	border: 1px solid black;
	border-collapse: collapse;
	text-align: center;
}
table td {
	border: 1px solid black;
	padding: 5px;
}
</style>
<table>
<thead>
<tr><th>Code</th><th>What it does</th><th>Example</th></tr>
</thead>
<tbody>
<tr><td colspan="3"><h4>Config Class</h4></td></tr>
<tr><td>Config::get('ITEM');</td><td>Gets Config Globals</td><td>Config::get('mysql/host') == 127.0.0.1</td></tr>
<tr><td colspan="3"><h4>DB Class</h4></td></tr>
<tr><td>DB::getInstance()->query("SELECT * FROM table WHERE x = ?", array('foo','bar'));</td><td>DB Query</td><td>{Code} will return query object</td></tr>
<tr><td colspan="3"><h4>Input Class</h4></td></tr>
<tr><td>Input::get('FOO');</td><td>Check $_POST then $_GET variables for FOO</td><td>Input::get('FOO'); == return $_POST/$_GET['FOO']</td></tr>
</tbody>
</table>